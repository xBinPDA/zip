echo -e "[ ${green}INFO${NC} ] Aight good ... installation file is ready"
echo -e "$green                                                                                         $NC"
echo -e "$green____ _  _ ___ ____    _ _  _ ____ ___ ____ _    _   $NC"
echo -e "$green|__| |  |  |  |  |    | |\ | [__   |  |__| |    |   $NC"
echo -e "$green|  | |__|  |  |__|    | | \| ___]  |  |  | |___ |___$NC"
echo -e "$green                                                      $NC"                                     
echo -e "$green                ____ ____ _  _$NC" 
echo -e "$green                [__  [__  |__|$NC"
echo -e "$green                ___] ___] |  |$NC"
echo -e "$green                $NC"                                                                                                                          
echo -e "$green♥ TERIMAKSIH TELAH MEMAKAI SCRIPT KINGSTORE ♥$NC"
sleep 2
sleep 5